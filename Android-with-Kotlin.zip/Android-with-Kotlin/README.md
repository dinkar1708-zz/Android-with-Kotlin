# Android-with-Kotlin
Kotlin code example for android projects.

## soon will add the performance in android code using kotlin
### ref - https://antonioleiva.com/kotlin-awesome-tricks-for-android/
